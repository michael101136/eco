<!DOCTYPE html>
<html lang="es">
		
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>MACHUPICCHU GOLDEN</title>
        <link rel="icon" type="image/png" href="/img/icons.png">
        
          <link href="https://allfont.es/allfont.css?fonts=roboto-light" rel="stylesheet" type="text/css" />
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
    <meta name="description" content="Machupicchu Golden ofrece tours para Machu Picchu, Huaynapicchu, Cusco, incluyen: Vuelos, guías, transporte, ingresos, trenes y mas."/>
    <meta property="og:title" content="Machupicchu Golden Tours a Machu Picchu, Tours en Cusco, Paquetes Machupicchu" />
    <meta property="og:description" content="Machupicchu Golden ofrece tours para Machu Picchu, Huaynapicchu, Cusco, incluyen: Vuelos, guías, transporte, ingresos, trenes y mas." />
 
    	 <?php echo $__env->make('assets.pagina.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
 <script>

  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '1588538331453581');
  fbq('track', 'PageView');
</script>
<noscript>
    <img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=1588538331453581&ev=PageView&noscript=1"
/>
</noscript>





<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-96012161-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-96012161-1');
</script>

</head>

<body>
    
    <script type='text/javascript'>
var _chatnox = _chatnox || [];_chatnox.setAccount = '184880002';
var cnox = document.createElement('script');cnox.type = 'text/javascript';
cnox.async = true;cnox.src = ('https:' == document.location.protocol ? 'https://app.chatnox.com' : 'http://app.chatnox.com') 
+ '/site/chat.js';
var s = document.getElementsByTagName('script')[0];
s.parentNode.insertBefore(cnox, s);
</script>
   
      <?php echo $__env->make('assets.pagina.es.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>




<!-- Footer Section -->
<BR>
<BR><BR><BR><BR><BR>
        <footer>
            <div class="container">
                <div class="row">
                    <!-- Address -->
                    <div class="col-sm-4 col-md-3">
                        <div class="footer-box">
                            <h4 class="footer-title">CONTACTO</h4>
                            <div class="address">
                                <i class="flaticon-placeholder"></i>
                                <p> Av. 28 de Julio Mz. R-2<br>
                                   Oficina 201 - Cusco</p>
                            </div>
                            <div class="address">
                                <i class="flaticon-customer-service"></i>
                                <p> 0051 084 584 272</p>
                            </div>
                            <div class="address">
                           
                                <p> MOVISTAR :+051 984 987 798</p>
                                <p> CLARO :+051 982 505 892</p>
                                <p> ENTEL :0051 084 584 272</p>
                            </div>
                            

                            <div class="address">
                                <i class="flaticon-mail"></i>
                                <p>reservas@machupicchugolden.com</p>
                                <p>info@machupicchugolden.com</p>
                                <p>ventas@machupicchugolden.com</p>
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-6">
                        <div class="row">
                            <div class="col-md-4 col-sm-4">
                                <div class="footer-box">
                                    <h4 class="footer-title">INFORMACI&OacuteN </h4>
                                    <ul class="categoty">

                                         <li><a href="<?php echo e(route('nosotrosEs','es')); ?>">ACERCA DE CUSCO</a></li>
                                       
                                    </ul>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-4">
                                <div class="footer-box">
                                    <h4 class="footer-title">SOCIOS</h4>
                                    <ul class="categoty">
                                        <li><a href="http://www.perumachupicchutravels.com/">PER&Uacute MACHUPICCHU TRAVEL</a></li>
                                      
                                    </ul>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-4">
                                <div class="footer-box">
                                    <h4 class="footer-title">DESTINOS</h4>
                                    <ul class="categoty">
                                        <li><a href="<?php echo e(route('paquetesCategoriaES',['idioma'=> 'es','categoria'=>'cusco'])); ?>">CUSCO</a></li>
                                        <li><a href="<?php echo e(route('paquetesCategoriaES',['idioma'=> 'es','categoria'=>'puno'])); ?>">PUNO</a></li>
                                        <li><a href="<?php echo e(route('paquetesCategoriaES',['idioma'=> 'es','categoria'=>'arequipa'])); ?>">AREQUIPA</a></li>
                                        <li><a href="<?php echo e(route('paquetesCategoriaES',['idioma'=> 'es','categoria'=>'lima'])); ?>">LIMA</a></li>
                                        <li><a href="<?php echo e(route('paquetesCategoriaES',['idioma'=> 'es','categoria'=>'selva'])); ?>">SELVA</a></li>
                                        <li><a href="<?php echo e(route('paquetesCategoriaES',['idioma'=> 'es','categoria'=>'nazca'])); ?>">NAZCA</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 hidden-sm">
                        <div class="footer-box">
                            <h4 class="footer-title">M&EacuteTODOS DE PAGO</h4>
                            <ul class="gallery-list">
                                <li> 
                                    <a href="https://www.visanetlink.pe/pagoseguro/MACHUPICCHUGOLDEN/33365" target="_blank">
                                        <img src="https://www.machupicchugolden.com/wp-content/uploads/2017/07/visanet-peru.jpg" alt="" style="height: 60px;width: 150px;">
                                    </a>
                                     <a href="https://www.paypal.com/cgi-bin/webscr" target="_blank">
                                        <img src="https://www.machupicchugolden.com/wp-content/uploads/2016/11/paypal-active-peru-treks.png" alt="" style="height: 60px;width: 150px;">
                                    </a>
                                     <a href="https://www.visanetlink.pe/pagoseguro/MACHUPICCHUGOLDEN/33365" target="_blank">
                                        <img src="https://www.machupicchugolden.com/wp-content/uploads/2016/11/western-union-active-peru-treks.jpg" alt="" style="height: 60px;width: 150px;">
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="sub-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-5">
                            <p>Developed by: machupicchu golden </p>
                        </div>
                        <div class="col-sm-7">
                            <div class="footer-menu">
                                <ul>
                                    <li><a href="/es">Inicio</a></li>
                                    <li><a href="<?php echo e(route('nosotrosEs','es')); ?>">Nosotros</a></li>
                                    <li><a href="<?php echo e(route('testimonioEs','es')); ?>">Testimonios</a></li>
                                    <li><a href="<?php echo e(route('contactoEs','es')); ?>">Contacto</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>


    	<!--========= scrip footer ===========-->
    	<?php echo $__env->make('assets.pagina.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    	<!--========= fin  ===========-->

    <?php echo $__env->yieldContent('script'); ?>


   
</html><?php /**PATH C:\xampp\htdocs\login\resources\views/assets/pagina/es/layouts/master.blade.php ENDPATH**/ ?>