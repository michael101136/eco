<?php echo Html::style('plantilla/assets/css/base.css'); ?>

<?php echo Html::style('plantilla/assets/css/responsive.css'); ?>

<?php /**PATH C:\xampp\htdocs\login\resources\views/assets/pagina/partials/header.blade.php ENDPATH**/ ?>