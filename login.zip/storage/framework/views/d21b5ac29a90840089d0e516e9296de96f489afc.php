

        <!-- jQuery -->
        <?php echo Html::script('plantilla/assets/js/jquery.min.js'); ?>

        <!-- jquery ui js -->
        <?php echo Html::script('plantilla/assets/js/jquery-ui.min.js'); ?>

        <!-- bootstrap js -->
        <?php echo Html::script('plantilla/assets/js/bootstrap.min.js'); ?>

        <!-- fraction slider js -->
        <?php echo Html::script('plantilla/assets/js/jquery.fractionslider.js'); ?>

        <!-- owl carousel js --> 
        <?php echo Html::script('plantilla/assets/owl-carousel/owl.carousel.min.js'); ?>

        <!-- counter -->
        <?php echo Html::script('plantilla/assets/js/jquery.counterup.min.js'); ?>

        <?php echo Html::script('plantilla/assets/js/waypoints.js'); ?>

        <!-- filter portfolio -->
        <?php echo Html::script('plantilla/assets/js/jquery.shuffle.min.js'); ?>

        <?php echo Html::script('plantilla/assets/js/portfolio.js'); ?>

        <!-- magnific popup -->
        <?php echo Html::script('plantilla/assets/js/jquery.magnific-popup.min.js'); ?>

        <!-- range slider -->
        <?php echo Html::script('plantilla/assets/js/ion.rangeSlider.min.js'); ?>

        <?php echo Html::script('plantilla/assets/js/jquery.easing.min.js'); ?>

        <!-- custom -->
        <?php echo Html::script('plantilla/assets/js/custom.js'); ?>


        
    </body>
</html><?php /**PATH C:\xampp\htdocs\login\resources\views/assets/pagina/partials/footer.blade.php ENDPATH**/ ?>