 <!-- page loader -->
        <div class="se-pre-con"></div>
        <div id="page-content">
            <!-- navber -->
            <nav id="mainNav" class="navbar navbar-fixed-top"  style="background: #fdfdfd; color: red;">
                <div class="container">
                    <!--Brand and toggle get grouped for better mobile display--> 
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span><i class="fa fa-bars"></i>
                        </button>
                        <a class="navbar-brand" href="/es">
                            <img src="/plantilla/assets/images/logo.png" class="img-resposive" alt=""  id="logoPrincipal">
                        </a>
                    </div>
                    <!--Collect the nav links, forms, and other content for toggling--> 
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <ul class="nav navbar-nav">
                            <li class="active"><a href="/es">Inicio</a></li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" class="active" >Paquetes<span class="caret"></span></a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="<?php echo e(route('paquetesCategoriaES',['idioma'=> 'es','categoria'=>'aventura'])); ?>">AVENTURA</a>
                                        <a href="<?php echo e(route('paquetesCategoriaES',['idioma'=> 'es','categoria'=>'místico'])); ?>">MÍSTICO</a>
                                        <a href="<?php echo e(route('paquetesCategoriaES',['idioma'=> 'es','categoria'=>'tradicional'])); ?>">TRADICIONAL</a>
                                        <a href="<?php echo e(route('paquetesCategoriaES',['idioma'=> 'es','categoria'=>'vivnecial'])); ?>">VIVENCIAL</a>
                                    </li>
                                   
                                </ul>
                            </li>
                            <li><a href="<?php echo e(route('nosotrosEs','es')); ?>">Nosotros</a></li>
                            <li><a href="<?php echo e(route('testimonioEs','es')); ?>">Testimonios</a></li>
                            <li><a href="<?php echo e(route('condicionesEs','es')); ?>">Condiciones</a></li>
                            <li><a href="<?php echo e(route('contactoEs','es')); ?>">Contacto</a></li>
                               <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" class="active" >
                                    <span class="glyphicon glyphicon-user"></span>
                                    <?php if(Auth::guest()): ?>
                                         Iniciar sesi&oacute;n
                                    <?php else: ?>
                                    <?php echo e(str_limit(auth()->user()->name,8)); ?>

                                    <?php endif; ?>
                                   
                                    
                                    <span class="caret"></span>
                                    </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        
                                        <?php if(Auth::guest()): ?>
                                           <a href="<?php echo e(route('register')); ?>">
                                              Crear cuenta</a>
                                          <a href="<?php echo e(route('login')); ?>">
                                              Iniciar sesi&oacute;n</a>
                                        <?php else: ?>
                                        <a href="<?php echo e(route('logout')); ?>">Cerrar sesi&oacute;n</a>
                                        
                                        <?php endif; ?>
                                       
                                   
                                        
                                    </li>
                                
                                </ul>
                            </li>
                            
                            <!--<?php if(Auth::guest()): ?>-->
                            
                            <!--<?php else: ?>-->
                              
                            <!--<?php endif; ?>-->

                        </ul>
                        <ul class="nav navbar-nav navbar-right hidden-sm">
                            <li>
                                    <?php if(Session::has('cart')): ?>
                                                <span class="badge" style="
                                                        margin-left: 10px;
                                                        position: absolute;
                                                    "> 
                                                <?php echo e(Session::has('cart') ? Session:: get('cart')->totalQty : ''); ?>    
                                                 </span>
                                            <?php endif; ?>
                                    <a class="nav-btn" href="<?php echo e(route('product.shoppingCartEs',['idioma' =>'es' ])); ?>">
                                          <span class="glyphicon glyphicon-shopping-cart"></span>  Carrito
                                            
                                            
                                            
                                    </a>
                            </li>
                            <li>
                                    <a class="nav-btn" href="/en">
                                            <img src="/plantilla/assets/images/bandera/en.png" id="Logo_idioma">
                                    </a>
                            </li>
                        </ul>
                    </div> 
                </div> 
            </nav> <?php /**PATH C:\xampp\htdocs\login\resources\views/assets/pagina/es/layouts/navbar.blade.php ENDPATH**/ ?>