<?php

namespace App\Http\Controllers;
use App\Tour;
use App\Cart;
use Illuminate\Http\Request;
use Session;
use App\Helpers\function1;
use Cookie;


class ProductController extends Controller
{
    
    public function getAddToCart(Request $request, $id)
    {

    	$producto =Tour::find($id);
    	$oldCart = Session:: has('cart') ? Session::get('cart') : null;
        
    	$cart = new Cart($oldCart);
              

    	$cart->add($producto,$producto->id);

    	$request->session()->put('cart', $cart);
    	return redirect()->back()->with('error', 'Something went wrong.');

    }

    public function getReduceByOne($id)
    {
        
        $oldCart = Session:: has('cart') ? Session::get('cart') : null;
    	$cart = new Cart($oldCart);
    	$cart->reduceByOne($id);
    	
    	Session::put('cart', $cart);
    	return redirect()->back()->with('error', 'Something went wrong.');
        
    }
    
    public function getRemoveItem($id)
    {
        
        $oldCart = Session:: has('cart') ? Session::get('cart') : null;
    	$cart = new Cart($oldCart);
    	$cart->removeItem($id);
    	
    	Session::put('cart', $cart);
    	return redirect()->back()->with('error', 'Something went wrong.');
        
    }
    
    public function getCart($idioma)
    {
    	
    	if(!Session:: has('cart')){

    		    return view("assets.pagina.".$idioma.".shopping",['products' => null]);
    	}

    	$oldCart =Session::get('cart');
    	$cart = new Cart($oldCart);

    	 return view("assets.pagina.".$idioma.".shopping",['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function getCheckout()
    {
    	
        $key = function1::securitykey('dev', 'giancagallardo@gmail.com' ,'Av3$truz');

        $contador =function1::contador();
        
        Cookie::queue('key', $key);
        Cookie::queue('contador', $contador);
        
       

       
        
      
    	$idioma="es";

    	if(!Session::has('cart'))
    	{
    		return redirect()->back()->with('error', 'Something went wrong.');
    	}
    	

    	$oldCart =Session::get('cart');
    	$cart = new Cart($oldCart);
    	$total = $cart->totalPrice;
    	Cookie::queue('total',$total);
        $sessionToken =function1::create_token('dev',$cart->totalPrice,$key);
        
      

    	return view("assets.pagina.".$idioma.".checkout",['total' => $total,'sessionToken'=>$sessionToken,'key'=>$key,'contador'=>$contador,'merchantId'=>'dev']);
    	

    }

    public function postCheckout(Request $request)
    {
    		dd($request->all());
    }
    
    public function transactionToken(Request $request)
    {
        
       
        $transactionToken =$request->transactionToken;
    	$entorno ='dev';
    
    	$purchaseNumber = $request->cookie('contador');
    	$amount = $request->cookie('total');
        $key=$request->cookie('key');
            
    	$respuesta = function1::authorization($entorno,$key,$amount,$transactionToken,$purchaseNumber);
    	Session::flash('pago', 'El pago se ha completado correctamente '); 
    	
        return redirect()->route('paquetesCategoriaES', ['idioma'=> 'es','categoria'=>'aventura']); 
         
        
    }
}
