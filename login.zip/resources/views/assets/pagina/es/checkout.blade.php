@extends('assets.pagina.es.layouts.master')

@section('content')
 
    <!-- page header -->
            <section class="header header-bg-10">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2">
                            <div class="header-content">
                                <div class="header-content-inner">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- contact -->
            <section class="contact-inner">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="contact_map">
                                <div class="container">                                
                                    <br>
                                   
                                  <?php 
                                  
                                    function entorno($data)
                                    {
                                            switch ($data) {
                                            case 'dev':
                                                $urljs="https://static-content-qas.vnforapps.com/v2/js/checkout.js?qa=true";
                                                $merchantId = merchantidtest;
                                                break;
                                            case 'prd':
                                                $urljs="https://static-content.vnforapps.com/v2/js/checkout.js";
                                                $merchantId = merchantidprd;
                                                break;
                                        }  
                                        
                                        return   $merchantId;
                                             
                                    } 
                                    
                                ?>
                              
   

                                     {!! Form::open(['route' => ['transaction'] , 'method' => 'POST', 'class' => 'form-horizontal']) !!}

                                                <script src='https://static-content-qas.vnforapps.com/v2/js/checkout.js?qa=true'
                                                data-sessiontoken='{{$sessionToken}}'
                                                data-channel='web'
                                                data-merchantid='<?=entorno($merchantId);?>'
                                                data-merchantlogo= 'https://www.machupicchugolden.com/plantilla/assets/images/logo_visaNet.png' data-formbuttoncolor='#09ab13'
                                                data-purchasenumber='{{$contador}}' 
                                                data-amount='{{$total}}'
                                                data-cardholdername='{{auth()->user()->name}}'
                                                data-cardholderlastname='{{auth()->user()->apellido}}'
                                                data-cardholderemail='{{auth()->user()->email}}'
                                                data-expirationminutes='5' data-timeouturl = 'timeout.html'>
                                                    
                                                </script>
                                                
                                 {!! Form::close() !!}

        
                                </div>
                            </div>
                        </div>
                      
                      
                    </div>
                </div>
            </section>
           
        </div>
        
        
       


@endsection

@section('script')
 

@endsection