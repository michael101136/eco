@extends('assets.pagina.es.layouts.master')

@section('content')
 

  
   <!-- about section -->
            <section class="about-section">
                <!-- about section -->
                <div class="about-inner">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-offset-2 col-md-8">
                                <div class="section-title text-center">
                                     <h1>ESTA PAGINA ESTA EN MANTENIMIENTO</h1>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="about-title">
                                  

                                
                                </div>
                                <div class="middle-content">
                                    <div class="row">
                                        <div class="col-sm-12 col-md-12">
                                            <img src="/img/machupicchu.jpg" class="img-responsive" alt="" style="height: 478px;">
                                        </div>
                                      
                                    </div>
                                </div>
                               
                            </div>
                        </div>
                    </div>
                </div>
              
                
            
        </div>


@endsection

@section('script')
  
 <script type="text/javascript">
       
 </script>
@endsection