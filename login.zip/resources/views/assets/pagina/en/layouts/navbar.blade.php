 <!-- page loader -->
        <div class="se-pre-con"></div>
        <div id="page-content">
            <!-- navber -->
            <nav id="mainNav" class="navbar navbar-fixed-top"  style="background: #fdfdfd; color: red;">
                <div class="container">
                    <!--Brand and toggle get grouped for better mobile display--> 
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span><i class="fa fa-bars"></i>
                        </button>
                        <a class="navbar-brand" href="/en">
                            <img src="/plantilla/assets/images/logo.png" class="img-resposive" alt=""  id="logoPrincipal">
                        </a>
                    </div>
                    <!--Collect the nav links, forms, and other content for toggling--> 
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <ul class="nav navbar-nav">
                            <li class="active"><a href="/en">Home</a></li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" class="active" >PACKAGES<span class="caret"></span></a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="{{route('paquetesCategoriaEN',['idioma'=> 'en','categoria'=>'adventure'])}}">ADVENTURE</a>
                                        <a href="{{route('paquetesCategoriaEN',['idioma'=> 'en','categoria'=>'mystical'])}}">MYSTICAL</a>
                                        <a href="{{route('paquetesCategoriaEN',['idioma'=> 'en','categoria'=>'traditional'])}}">TRADITIONAL</a>
                                        <a href="{{route('paquetesCategoriaEN',['idioma'=> 'en','categoria'=>'experiential'])}}">EXPERIENTIAL</a>
                                    </li>
                                   
                                </ul>
                            </li>
                            <li><a href="{{ route('nosotrosEn','en') }}">About us</a></li>
                            <li><a href="{{route('testimonioEn','en')}}">Testimonials</a></li>
                            <li><a href="{{ route('condicionesEn','en') }}">Terms and Conditions</a></li>
                            <li><a href="{{ route('contactoEn','en') }}">Contact</a></li>
                            

                        </ul>
                        <ul class="nav navbar-nav navbar-right hidden-sm">
                            <li>
                                    <a class="nav-btn" href="{{route('product.shoppingCart',['idioma' =>'en' ])}}">
                                            <i class="fa fa-shopping-cart" aria-hidden="true"></i> Cart 
                                            
                                            @if (Session::has('cart'))
                                                <span class="badge"> 
                                                {{Session::has('cart') ? Session:: get('cart')->totalQty : ''}}    
                                                 </span>
                                            @endif
                                            
                                    </a>
                            </li>
                            <li>
                                    <a class="nav-btn" href="/es">
                                            <img src="/plantilla/assets/images/bandera/es.png" id="Logo_idioma">
                                    </a>
                            </li>
                        </ul>
                    </div> 
                </div> 
            </nav> 