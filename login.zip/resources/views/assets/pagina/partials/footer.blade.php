

        <!-- jQuery -->
        {!!Html::script('plantilla/assets/js/jquery.min.js')!!}
        <!-- jquery ui js -->
        {!!Html::script('plantilla/assets/js/jquery-ui.min.js')!!}
        <!-- bootstrap js -->
        {!!Html::script('plantilla/assets/js/bootstrap.min.js')!!}
        <!-- fraction slider js -->
        {!!Html::script('plantilla/assets/js/jquery.fractionslider.js')!!}
        <!-- owl carousel js --> 
        {!!Html::script('plantilla/assets/owl-carousel/owl.carousel.min.js')!!}
        <!-- counter -->
        {!!Html::script('plantilla/assets/js/jquery.counterup.min.js')!!}
        {!!Html::script('plantilla/assets/js/waypoints.js')!!}
        <!-- filter portfolio -->
        {!!Html::script('plantilla/assets/js/jquery.shuffle.min.js')!!}
        {!!Html::script('plantilla/assets/js/portfolio.js')!!}
        <!-- magnific popup -->
        {!!Html::script('plantilla/assets/js/jquery.magnific-popup.min.js')!!}
        <!-- range slider -->
        {!!Html::script('plantilla/assets/js/ion.rangeSlider.min.js')!!}
        {!!Html::script('plantilla/assets/js/jquery.easing.min.js')!!}
        <!-- custom -->
        {!!Html::script('plantilla/assets/js/custom.js')!!}

        
    </body>
</html>