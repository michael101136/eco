{!!Html::style('plantilla/assets/css/base.css')!!}
{!!Html::style('plantilla/assets/css/responsive.css')!!}
